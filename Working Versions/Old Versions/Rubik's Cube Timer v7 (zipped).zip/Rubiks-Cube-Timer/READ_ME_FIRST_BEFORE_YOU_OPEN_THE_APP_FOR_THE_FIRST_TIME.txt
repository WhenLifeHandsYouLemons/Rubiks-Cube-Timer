HOW TO SETUP APPLICATION BEFORE USING IT

1. Move the "Rubiks-Cube-Timer" folder into the "C:" drive.
2. Open the folder, find and run the "Rubik's Cube Timer.exe" file. (The file may not show the ".exe" part, but it's still ok.)
3. Pin the application to your taskbar to find it easily next time.
4. Enjoy cubing!