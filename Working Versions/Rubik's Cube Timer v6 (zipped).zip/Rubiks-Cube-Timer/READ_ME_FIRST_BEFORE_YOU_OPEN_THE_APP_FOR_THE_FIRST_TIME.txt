HOW TO SETUP APPLICATION BEFORE USING IT

1. Unzip the "Rubik's Cube Timer v6 (zipped)" folder.
2. Move the "Rubiks-Cube-Timer" folder into the "C:" drive.
3. Open the folder, find and run the "Rubik's Cube Timer.exe" file. (The file may not show the ".exe" part, but it's still ok.)
4. Pin the application to your taskbar to find it easily next time.
5. Enjoy cubing!